# NEO TURBO AGENT - Documentação de Arquitetura

## 📐 VISÃO GERAL DA ARQUITETURA

O **NEO TURBO AGENT** segue uma arquitetura híbrida que combina **Flutter** (camada de apresentação) com **Kotlin** (camada nativa de baixo nível), comunicando-se através de **MethodChannel**.

```
┌─────────────────────────────────────────────────────────────┐
│                    CAMADA DE APRESENTAÇÃO                    │
│                         (Flutter/Dart)                       │
│  ┌────────────────────────────────────────────────────────┐ │
│  │  main.dart                                             │ │
│  │  - NeoTurboApp (MaterialApp)                          │ │
│  │  - NeoTurboHome (UI Cyberpunk)                        │ │
│  │  - NeoTurboState (Provider State Management)          │ │
│  └────────────────────────────────────────────────────────┘ │
└─────────────────────────────────────────────────────────────┘
                              ↕ MethodChannel
┌─────────────────────────────────────────────────────────────┐
│                     CAMADA NATIVA (Kotlin)                   │
│  ┌────────────────────────────────────────────────────────┐ │
│  │  MainActivity.kt (Ponte Flutter-Kotlin)                │ │
│  │  - checkPermissions()                                  │ │
│  │  - requestPermissions()                                │ │
│  │  - startOverlayService()                               │ │
│  │  - optimizeRAM()                                       │ │
│  └────────────────────────────────────────────────────────┘ │
│  ┌────────────────────────────────────────────────────────┐ │
│  │  OverlayService.kt (Foreground Service)                │ │
│  │  - createOverlayView()                                 │ │
│  │  - OverlayTouchListener (Drag & Drop)                  │ │
│  └────────────────────────────────────────────────────────┘ │
│  ┌────────────────────────────────────────────────────────┐ │
│  │  NeoAccessibilityService.kt (Keymapper)                │ │
│  │  - performTouchGesture()                               │ │
│  │  - performSwipeGesture()                               │ │
│  │  - performMultiTouch()                                 │ │
│  └────────────────────────────────────────────────────────┘ │
│  ┌────────────────────────────────────────────────────────┐ │
│  │  SystemOptimizer.kt (RAM/CPU)                          │ │
│  │  - optimizeRAM()                                       │ │
│  │  - getRAMInfo()                                        │ │
│  │  - getCPUUsage()                                       │ │
│  └────────────────────────────────────────────────────────┘ │
└─────────────────────────────────────────────────────────────┘
                              ↕
┌─────────────────────────────────────────────────────────────┐
│                    SISTEMA ANDROID (API)                     │
│  - WindowManager (Overlay)                                  │
│  - AccessibilityService (Gestures)                          │
│  - ActivityManager (RAM Management)                         │
│  - AppOpsManager (Permissions)                              │
└─────────────────────────────────────────────────────────────┘
```

---

## 🔌 COMUNICAÇÃO FLUTTER ↔ KOTLIN

### MethodChannel

O **MethodChannel** é a ponte de comunicação bidirecional entre Flutter e Kotlin.

#### Configuração (MainActivity.kt)
```kotlin
private val CHANNEL = "com.neoturbo.agent/native"
private var methodChannel: MethodChannel? = null

methodChannel = MethodChannel(flutterEngine.dartExecutor.binaryMessenger, CHANNEL)
methodChannel?.setMethodCallHandler { call, result ->
    when (call.method) {
        "checkPermissions" -> result.success(checkAllPermissions())
        "optimizeRAM" -> result.success(SystemOptimizer.optimizeRAM(this))
        // ...
    }
}
```

#### Uso (main.dart)
```dart
static const platform = MethodChannel('com.neoturbo.agent/native');

Future<void> checkPermissions() async {
  final result = await platform.invokeMethod('checkPermissions');
  // Processar resultado
}
```

### Métodos Disponíveis

| Método | Parâmetros | Retorno | Descrição |
|--------|-----------|---------|-----------|
| `checkPermissions` | - | `Map<String, Boolean>` | Verifica status de todas as permissões |
| `requestOverlayPermission` | - | `Boolean` | Abre configurações de overlay |
| `requestAccessibilityPermission` | - | `Boolean` | Abre configurações de acessibilidade |
| `requestUsageStatsPermission` | - | `Boolean` | Abre configurações de usage stats |
| `startOverlayService` | - | `Boolean` | Inicia o serviço de overlay |
| `stopOverlayService` | - | `Boolean` | Para o serviço de overlay |
| `optimizeRAM` | - | `Int` | Otimiza RAM e retorna MB liberados |
| `getRAMInfo` | - | `Map<String, Any>` | Retorna informações detalhadas de RAM |
| `simulateTouch` | `x: Double, y: Double` | `Boolean` | Simula toque em coordenadas |

---

## 🔐 GERENCIAMENTO DE PERMISSÕES

### Estratégia Multi-Versão

O app implementa verificação e solicitação de permissões adaptadas para cada versão do Android:

#### 1. Overlay Permission (SYSTEM_ALERT_WINDOW)

**Android 6.0+ (API 23+)**
```kotlin
if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
    val intent = Intent(
        Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
        Uri.parse("package:$packageName")
    )
    startActivityForResult(intent, REQUEST_OVERLAY_PERMISSION)
}
```

**Android 5.0-5.1 (API 21-22)**
- Permissão concedida automaticamente no AndroidManifest.xml
- Não requer solicitação runtime

#### 2. Accessibility Service

**Todas as versões**
```kotlin
val intent = Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)
startActivityForResult(intent, REQUEST_ACCESSIBILITY_PERMISSION)
```

**Verificação**
```kotlin
val accessibilityEnabled = Settings.Secure.getInt(
    contentResolver,
    Settings.Secure.ACCESSIBILITY_ENABLED
)
val services = Settings.Secure.getString(
    contentResolver,
    Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES
)
return services?.contains(packageName) == true
```

#### 3. Usage Stats (PACKAGE_USAGE_STATS)

**Android 5.0+ (API 21+)**
```kotlin
val appOps = getSystemService(Context.APP_OPS_SERVICE) as AppOpsManager
val mode = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
    appOps.unsafeCheckOpNoThrow(...)
} else {
    appOps.checkOpNoThrow(...)
}
return mode == AppOpsManager.MODE_ALLOWED
```

### Fluxo de Permissões

```
[App Inicia]
     ↓
[checkPermissions()]
     ↓
┌────────────────────┐
│ Todas concedidas?  │
└────────────────────┘
     ↓ Não
[Exibir status com ícone de cadeado]
     ↓
[Usuário clica em "GRANT"]
     ↓
[requestXXXPermission()]
     ↓
[Intent para Settings]
     ↓
[Usuário concede permissão]
     ↓
[Volta ao app]
     ↓
[checkPermissions() novamente]
     ↓ Sim
[Desbloquear botão TURBO]
```

---

## 🪟 OVERLAY SERVICE

### Arquitetura do Serviço

O **OverlayService** é um **Foreground Service** que mantém uma view flutuante sobre outros apps.

#### Ciclo de Vida

```
[startOverlayService()]
     ↓
[onCreate()]
     ↓
[createNotificationChannel()] (Android 8.0+)
     ↓
[startForeground(NOTIFICATION_ID, notification)]
     ↓
[onStartCommand()]
     ↓
[createOverlayView()]
     ↓
[windowManager.addView(overlayView, params)]
     ↓
[Overlay ativo e visível]
     ↓
[stopOverlayService()]
     ↓
[onDestroy()]
     ↓
[windowManager.removeView(overlayView)]
```

#### Tipos de Overlay por Versão

| Android Version | API Level | Window Type |
|----------------|-----------|-------------|
| 8.0+ | 26+ | `TYPE_APPLICATION_OVERLAY` |
| 6.0-7.1 | 23-25 | `TYPE_PHONE` (deprecated) |
| 5.0-5.1 | 21-22 | `TYPE_SYSTEM_ALERT` (deprecated) |

**Implementação**
```kotlin
private fun getOverlayType(): Int {
    return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
        WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
    } else if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
        @Suppress("DEPRECATION")
        WindowManager.LayoutParams.TYPE_PHONE
    } else {
        @Suppress("DEPRECATION")
        WindowManager.LayoutParams.TYPE_SYSTEM_ALERT
    }
}
```

#### Drag & Drop

O overlay implementa um **TouchListener** customizado:

```kotlin
private inner class OverlayTouchListener : View.OnTouchListener {
    private var initialX = 0
    private var initialY = 0
    private var initialTouchX = 0f
    private var initialTouchY = 0f

    override fun onTouch(v: View?, event: MotionEvent?): Boolean {
        when (event?.action) {
            MotionEvent.ACTION_DOWN -> {
                // Salvar posição inicial
            }
            MotionEvent.ACTION_MOVE -> {
                // Atualizar posição
                params?.x = initialX + (event.rawX - initialTouchX).toInt()
                params?.y = initialY + (event.rawY - initialTouchY).toInt()
                windowManager?.updateViewLayout(overlayView, params)
            }
        }
        return false
    }
}
```

### Foreground Service

**Por que Foreground?**
- Previne que o sistema mate o serviço (OOM Killer)
- Essencial em dispositivos Xiaomi/Samsung com otimizações agressivas
- Requer notificação persistente (obrigatório no Android 8.0+)

**Android 14+ (API 34)**
```xml
<service
    android:name=".OverlayService"
    android:foregroundServiceType="specialUse">
    <property
        android:name="android.app.PROPERTY_SPECIAL_USE_FGS_SUBTYPE"
        android:value="Game Optimization Overlay" />
</service>
```

---

## 🎮 ACCESSIBILITY SERVICE (KEYMAPPER)

### Arquitetura

O **NeoAccessibilityService** estende `AccessibilityService` e utiliza `dispatchGesture()` para simular toques.

#### Configuração (accessibility_service_config.xml)

```xml
<accessibility-service
    android:accessibilityEventTypes="typeAllMask"
    android:accessibilityFeedbackType="feedbackGeneric"
    android:canPerformGestures="true"
    android:canRetrieveWindowContent="true"
    android:description="@string/accessibility_service_description" />
```

#### Simulação de Toque

**Requer Android 7.0+ (API 24)**

```kotlin
@RequiresApi(Build.VERSION_CODES.N)
private fun performTouchGesture(x: Float, y: Float) {
    val path = Path()
    path.moveTo(x, y)
    
    val gestureBuilder = GestureDescription.Builder()
    val strokeDescription = GestureDescription.StrokeDescription(
        path,
        0,   // delay inicial (ms)
        50   // duração do toque (ms)
    )
    
    gestureBuilder.addStroke(strokeDescription)
    val gesture = gestureBuilder.build()
    
    dispatchGesture(gesture, object : GestureResultCallback() {
        override fun onCompleted(gestureDescription: GestureDescription?) {
            // Sucesso
        }
        override fun onCancelled(gestureDescription: GestureDescription?) {
            // Cancelado
        }
    }, null)
}
```

#### Tipos de Gestos Suportados

| Gesto | Método | Parâmetros |
|-------|--------|-----------|
| Toque simples | `performTouchGesture()` | `x, y` |
| Swipe | `performSwipeGesture()` | `startX, startY, endX, endY, duration` |
| Multi-touch | `performMultiTouch()` | `List<Pair<Float, Float>>` |

#### Singleton Pattern

```kotlin
companion object {
    private var instance: NeoAccessibilityService? = null
    
    fun simulateTouch(x: Float, y: Float) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
            instance?.performTouchGesture(x, y)
        }
    }
}

override fun onServiceConnected() {
    super.onServiceConnected()
    instance = this
}

override fun onDestroy() {
    instance = null
    super.onDestroy()
}
```

---

## 🧠 SYSTEM OPTIMIZER

### Otimização de RAM

#### Estratégia

1. **Obter RAM antes da limpeza**
2. **Matar processos em background** (exceto o próprio app)
3. **Forçar Garbage Collection**
4. **Aguardar 500ms** (sistema atualizar)
5. **Obter RAM depois da limpeza**
6. **Calcular diferença**

#### Implementação

```kotlin
fun optimizeRAM(context: Context): Int {
    val activityManager = context.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
    
    val memInfoBefore = getRAMInfo(context)
    val availableBefore = memInfoBefore["available"] as? Long ?: 0L
    
    val runningApps = activityManager.runningAppProcesses
    runningApps?.forEach { processInfo ->
        if (processInfo.importance >= ActivityManager.RunningAppProcessInfo.IMPORTANCE_BACKGROUND) {
            if (processInfo.processName != context.packageName) {
                activityManager.killBackgroundProcesses(processInfo.processName)
            }
        }
    }
    
    System.gc()
    Thread.sleep(500)
    
    val memInfoAfter = getRAMInfo(context)
    val availableAfter = memInfoAfter["available"] as? Long ?: 0L
    
    return ((availableAfter - availableBefore) / (1024 * 1024)).toInt()
}
```

### Monitoramento de RAM

#### Leitura de /proc/meminfo

```kotlin
private fun getTotalRAM(): Long {
    val reader = RandomAccessFile("/proc/meminfo", "r")
    val line = reader.readLine()
    reader.close()
    
    // Formato: "MemTotal:        3951236 kB"
    val parts = line.split("\\s+".toRegex())
    val totalKB = parts[1].toLongOrNull() ?: 0L
    return totalKB * 1024 // Converter para bytes
}
```

#### Informações Retornadas

```kotlin
mapOf(
    "total" to totalRAM,           // bytes
    "available" to availableRAM,   // bytes
    "used" to usedRAM,             // bytes
    "usedPercentage" to usedPercentage,  // 0-100
    "totalMB" to (totalRAM / (1024 * 1024)),
    "availableMB" to (availableRAM / (1024 * 1024)),
    "usedMB" to (usedRAM / (1024 * 1024)),
    "isLowMemory" to memInfo.lowMemory,
    "threshold" to memInfo.threshold
)
```

---

## 🎨 UI CYBERPUNK (FLUTTER)

### Paleta de Cores

```dart
const Color cyanNeon = Color(0xFF00f3ff);    // Cyan
const Color greenNeon = Color(0xFF39ff14);   // Neon Green
const Color darkBg = Color(0xFF0a0e27);      // Background escuro
const Color surfaceDark = Color(0xFF1a1f3a); // Surface
```

### Componentes Principais

#### 1. Dashboard de RAM

```dart
Widget _buildRAMMonitor() {
  return Container(
    decoration: BoxDecoration(
      color: surfaceDark.withOpacity(0.5),
      borderRadius: BorderRadius.circular(15),
      border: Border.all(color: cyanNeon.withOpacity(0.3), width: 2),
      boxShadow: [
        BoxShadow(
          color: cyanNeon.withOpacity(0.2),
          blurRadius: 20,
          spreadRadius: 2,
        ),
      ],
    ),
    child: Column(
      children: [
        _buildRAMBar(state.ramUsedPercentage),
        _buildRAMStats(),
      ],
    ),
  );
}
```

#### 2. Botão TURBO

**Estados:**
- **Locked** (sem permissões): Ícone de cadeado, cor cinza
- **Inactive** (com permissões): Ícone de raio apagado, cor cyan
- **Active** (turbo ativo): Ícone de raio aceso, cor green neon

```dart
Widget _buildTurboButton() {
  final isEnabled = state.allPermissionsGranted;
  final isActive = state.isTurboActive;
  
  return Container(
    width: 200,
    height: 200,
    decoration: BoxDecoration(
      shape: BoxShape.circle,
      gradient: isEnabled ? RadialGradient(...) : RadialGradient(...),
      boxShadow: isEnabled ? [BoxShadow(...)] : [],
    ),
    child: Icon(
      isEnabled ? (isActive ? Icons.flash_on : Icons.flash_off) : Icons.lock,
      size: 80,
    ),
  );
}
```

### Animações

#### AnimatedTextKit (Header)
```dart
AnimatedTextKit(
  animatedTexts: [
    TypewriterAnimatedText(
      'NEO TURBO AGENT',
      textStyle: TextStyle(fontSize: 28, color: cyanNeon),
      speed: Duration(milliseconds: 100),
    ),
  ],
  totalRepeatCount: 1,
)
```

#### SpinKit (Loading)
```dart
SpinKitPulse(color: greenNeon, size: 20)
SpinKitThreeBounce(color: cyanNeon, size: 20)
```

---

## 🛡️ ESTRATÉGIAS ANTI-CRASH

### 1. Try-Catch Universal

**Todas** as chamadas nativas estão envoltas em try-catch:

```dart
Future<void> checkPermissions() async {
  try {
    final result = await platform.invokeMethod('checkPermissions');
    // Processar resultado
  } catch (e) {
    print('Error checking permissions: $e');
  }
}
```

```kotlin
methodChannel?.setMethodCallHandler { call, result ->
    try {
        when (call.method) {
            "checkPermissions" -> result.success(checkAllPermissions())
        }
    } catch (e: Exception) {
        result.error("ERROR", e.message, e.stackTraceToString())
    }
}
```

### 2. Verificação Antes de Executar

```kotlin
private fun startOverlayService() {
    if (!hasOverlayPermission()) {
        throw SecurityException("Overlay permission not granted")
    }
    // Iniciar serviço
}
```

### 3. Foreground Service com START_STICKY

```kotlin
override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
    // ...
    return START_STICKY  // Reinicia se morto pelo sistema
}
```

### 4. Compatibilidade de API

```kotlin
if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
    startForegroundService(intent)
} else {
    startService(intent)
}
```

---

## 📊 FLUXO DE DADOS

### Atualização de RAM (Auto-refresh)

```
[Timer.periodic(2 segundos)]
     ↓
[state.updateRAMInfo()]
     ↓
[platform.invokeMethod('getRAMInfo')]
     ↓
[SystemOptimizer.getRAMInfo(context)]
     ↓
[Lê /proc/meminfo + ActivityManager]
     ↓
[Retorna Map<String, Any>]
     ↓
[state atualiza variáveis]
     ↓
[notifyListeners()]
     ↓
[UI atualiza automaticamente (Consumer)]
```

### Otimização de RAM

```
[Usuário clica "OPTIMIZE RAM"]
     ↓
[state.optimizeRAM()]
     ↓
[platform.invokeMethod('optimizeRAM')]
     ↓
[SystemOptimizer.optimizeRAM(context)]
     ↓
[killBackgroundProcesses() + System.gc()]
     ↓
[Retorna MB liberados]
     ↓
[Exibe SnackBar com resultado]
     ↓
[state.updateRAMInfo() (refresh)]
```

---

## 🔧 BUILD E RELEASE

### Debug Build

```bash
flutter build apk --debug
```

### Release Build (Otimizado)

```bash
flutter build apk --release
```

**Otimizações aplicadas:**
- ProGuard: Ofusca e minifica código Kotlin
- `minifyEnabled true`
- `shrinkResources true`
- Remoção de logs (Log.d, Log.v, Log.i)

### Assinatura de App

Para produção, configure `signingConfigs` no `build.gradle`:

```gradle
signingConfigs {
    release {
        storeFile file("keystore.jks")
        storePassword "senha"
        keyAlias "alias"
        keyPassword "senha"
    }
}

buildTypes {
    release {
        signingConfig signingConfigs.release
    }
}
```

---

## 📈 PERFORMANCE

### Métricas Esperadas

| Métrica | Valor |
|---------|-------|
| Tamanho do APK (release) | ~15-25 MB |
| Uso de RAM (idle) | ~80-120 MB |
| Uso de RAM (ativo) | ~120-180 MB |
| Tempo de inicialização | <2 segundos |
| Latência de toque (keymapper) | ~50-100 ms |
| RAM liberada (otimização) | 50-500 MB (varia) |

### Otimizações Implementadas

1. **Foreground Service**: Previne morte pelo sistema
2. **Timer eficiente**: Atualiza RAM a cada 2s (não bloqueia UI)
3. **Lazy loading**: Permissões verificadas sob demanda
4. **ProGuard**: Reduz tamanho do APK em ~30%
5. **MultiDex**: Suporta grande quantidade de métodos

---

## 🧪 TESTES

### Testes Unitários (Recomendados)

```dart
// test/neo_turbo_state_test.dart
void main() {
  test('checkPermissions should update state', () async {
    final state = NeoTurboState();
    await state.checkPermissions();
    expect(state.hasOverlayPermission, isNotNull);
  });
}
```

### Testes de Integração

```dart
// integration_test/app_test.dart
void main() {
  testWidgets('Turbo button should be locked without permissions', (tester) async {
    await tester.pumpWidget(NeoTurboApp());
    final button = find.byIcon(Icons.lock);
    expect(button, findsOneWidget);
  });
}
```

---

## 🚀 ROADMAP FUTURO

### Funcionalidades Planejadas

- [ ] Keymapper visual (arrastar e posicionar botões)
- [ ] Perfis de otimização por jogo
- [ ] Monitoramento de FPS em tempo real
- [ ] Gravação de macros (sequências de toques)
- [ ] Modo noturno automático
- [ ] Estatísticas de uso (gráficos históricos)
- [ ] Suporte a temas customizados
- [ ] Integração com Game Launcher

### Melhorias Técnicas

- [ ] Migrar para Kotlin Coroutines (async/await)
- [ ] Implementar Room Database (persistência)
- [ ] Adicionar testes automatizados (CI/CD)
- [ ] Suporte a Android 15+ (futuras APIs)
- [ ] Otimização de bateria (Doze Mode)

---

**Desenvolvido com ⚡ seguindo princípios de Clean Architecture e SOLID**
