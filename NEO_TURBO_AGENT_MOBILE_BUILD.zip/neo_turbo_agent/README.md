# NEO TURBO AGENT 🚀

**Otimizador de Jogos de Alta Performance para Android**

Um ecossistema completo de otimização de jogos desenvolvido com **Flutter** (Frontend) e **Kotlin** (Backend nativo), compatível com Android 5.0 (Lollipop) até Android 14+.

---

## 🎯 CARACTERÍSTICAS PRINCIPAIS

### ✨ Funcionalidades Core
- **Overlay Flutuante**: View flutuante arrastável que permanece sobre jogos
- **Keymapper Avançado**: Simulação de toques via Accessibility Service
- **Otimização de RAM**: Limpeza inteligente de processos em background
- **Monitoramento em Tempo Real**: Dashboard com estatísticas de CPU/RAM
- **UI Cyberpunk Imersiva**: Interface dark mode com cores neon (#00f3ff e #39ff14)
- **Foreground Services**: Estabilidade máxima contra OOM Killer

### 🛡️ Compatibilidade
- **Android 5.0 (API 21)** até **Android 14+ (API 34)**
- Gerenciamento inteligente de permissões por versão
- Suporte a dispositivos Legacy e Modern

---

## 🏗️ ARQUITETURA

```
neo_turbo_agent/
├── android/
│   └── app/
│       └── src/
│           └── main/
│               ├── AndroidManifest.xml          # Permissões e configurações
│               ├── res/
│               │   ├── xml/
│               │   │   └── accessibility_service_config.xml
│               │   └── values/
│               │       └── strings.xml
│               └── kotlin/com/neoturbo/agent/
│                   ├── MainActivity.kt           # Ponte Flutter-Kotlin
│                   ├── OverlayService.kt         # Serviço de overlay flutuante
│                   ├── NeoAccessibilityService.kt # Keymapper (gestos)
│                   └── SystemOptimizer.kt        # Otimização de RAM/CPU
├── lib/
│   └── main.dart                                # UI Flutter + State Management
└── pubspec.yaml                                 # Dependências Flutter
```

---

## 📦 INSTALAÇÃO

### Pré-requisitos
- Flutter SDK 3.0.0+
- Android SDK (API 21-34)
- Kotlin 1.8+
- Gradle 7.0+

### Passos

1. **Clone o projeto**
```bash
git clone <seu-repositorio>
cd neo_turbo_agent
```

2. **Instale dependências Flutter**
```bash
flutter pub get
```

3. **Configure o Android**
```bash
cd android
./gradlew clean
cd ..
```

4. **Execute no dispositivo/emulador**
```bash
flutter run
```

---

## 🔐 PERMISSÕES NECESSÁRIAS

O app requer **3 permissões críticas** para funcionar:

### 1. **Overlay Window** (SYSTEM_ALERT_WINDOW)
- Permite criar views flutuantes sobre outros apps
- **Como conceder**: Settings → Apps → NEO TURBO → Display over other apps

### 2. **Accessibility Service** (BIND_ACCESSIBILITY_SERVICE)
- Permite simular toques e gestos (Keymapper)
- **Como conceder**: Settings → Accessibility → NEO TURBO → Enable

### 3. **Usage Stats** (PACKAGE_USAGE_STATS)
- Permite monitorar uso de apps
- **Como conceder**: Settings → Apps → Special access → Usage access → NEO TURBO

> ⚠️ **IMPORTANTE**: O botão TURBO ficará **bloqueado** (ícone de cadeado) até que todas as 3 permissões sejam concedidas.

---

## 🚀 COMO USAR

### 1. Primeira Execução
1. Abra o app
2. Clique em **GRANT** ao lado de cada permissão
3. Siga as instruções do sistema para conceder cada permissão
4. Volte ao app e clique em **REFRESH STATUS**

### 2. Ativar Modo Turbo
1. Com todas as permissões concedidas, o botão TURBO ficará **desbloqueado**
2. Toque no botão circular TURBO
3. O overlay flutuante aparecerá na tela
4. Status mudará para **ACTIVE** (verde neon)

### 3. Otimizar RAM
1. Toque no botão **OPTIMIZE RAM**
2. O sistema matará processos em background
3. Uma notificação mostrará a quantidade de RAM liberada

### 4. Monitoramento
- O dashboard atualiza automaticamente a cada 2 segundos
- Visualize: RAM Total, Usada, Livre e Percentual de Uso

---

## 🛠️ DETALHES TÉCNICOS

### Camada Nativa (Kotlin)

#### MainActivity.kt
- **MethodChannel**: Ponte de comunicação Flutter ↔ Kotlin
- **Gerenciamento de Permissões**: Detecta versão do Android e usa Intent apropriada
- **Try-Catch Obrigatório**: Evita crashes por permissões não concedidas

#### OverlayService.kt
- **Foreground Service**: Mantém o serviço vivo (notificação obrigatória)
- **WindowManager**: Gerencia a view flutuante
- **Compatibilidade de Tipos**:
  - API 26+: `TYPE_APPLICATION_OVERLAY`
  - API 23-25: `TYPE_PHONE`
  - API 21-22: `TYPE_SYSTEM_ALERT`
- **TouchListener**: Permite arrastar o overlay pela tela

#### NeoAccessibilityService.kt
- **dispatchGesture**: Simula toques em coordenadas (x, y)
- **Requer API 24+**: Gestos não funcionam em Android < 7.0
- **Suporte a Multi-touch**: Pode simular múltiplos toques simultâneos

#### SystemOptimizer.kt
- **killBackgroundProcesses**: Mata apps em background
- **getRAMInfo**: Lê `/proc/meminfo` para precisão máxima
- **Garbage Collection**: Força `System.gc()` após limpeza

### Camada Visual (Flutter)

#### UI Cyberpunk
- **Cores**: Cyan (#00f3ff) e Neon Green (#39ff14)
- **Gradientes**: RadialGradient e LinearGradient
- **Animações**: AnimatedTextKit, SpinKit
- **Glow Effects**: BoxShadow com blur e spread

#### State Management (Provider)
- **NeoTurboState**: Gerencia estado global do app
- **MethodChannel**: Comunicação assíncrona com Kotlin
- **Auto-refresh**: Timer para atualizar RAM a cada 2s

#### Lógica de Botão Turbo
```dart
final isEnabled = state.allPermissionsGranted;
// Botão só fica ativo se todas as 3 permissões estiverem concedidas
```

---

## 🛡️ PROTOCOLO ANTI-CRASH

### Estratégias Implementadas

1. **Try-Catch em Todas as Chamadas Nativas**
```kotlin
try {
    // Operação nativa
} catch (e: Exception) {
    e.printStackTrace()
    result.error("ERROR", e.message, e.stackTraceToString())
}
```

2. **Verificação de Permissões Antes de Executar**
```kotlin
if (!hasOverlayPermission()) {
    throw SecurityException("Overlay permission not granted")
}
```

3. **Foreground Service com Notificação**
- Previne que o sistema mate o app em dispositivos Xiaomi/Samsung
- `START_STICKY`: Reinicia automaticamente se morto

4. **Compatibilidade de API**
```kotlin
if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
    // Código para Android 8.0+
} else {
    // Fallback para versões antigas
}
```

---

## 📱 TESTES RECOMENDADOS

### Dispositivos Reais
- **Xiaomi**: Testar com MIUI (agressivo com bateria)
- **Samsung**: Testar com One UI (otimizações de bateria)
- **Stock Android**: Pixel, Motorola

### Cenários de Teste
1. ✅ Conceder permissões uma a uma
2. ✅ Revogar permissões e verificar bloqueio do botão
3. ✅ Ativar Turbo e verificar overlay flutuante
4. ✅ Arrastar overlay pela tela
5. ✅ Otimizar RAM e verificar memória liberada
6. ✅ Deixar app em background e verificar se serviço permanece ativo
7. ✅ Reiniciar dispositivo e verificar estado das permissões

---

## 🐛 TROUBLESHOOTING

### Problema: "App parou de funcionar"
**Solução**: Verifique se todas as permissões foram concedidas antes de ativar o Turbo.

### Problema: Overlay não aparece
**Solução**: 
1. Verifique se a permissão de Overlay foi concedida
2. Em alguns dispositivos, vá em Settings → Display → Display over other apps

### Problema: Keymapper não funciona
**Solução**:
1. Verifique se o Accessibility Service está ativo
2. Settings → Accessibility → NEO TURBO → Enable
3. Requer Android 7.0+ (API 24)

### Problema: RAM não é otimizada
**Solução**:
- A otimização depende de processos em background
- Alguns apps do sistema não podem ser mortos
- Resultado pode variar entre 0-500 MB

---

## 📄 LICENÇA

Este projeto é fornecido "como está", sem garantias. Use por sua conta e risco.

---

## 🤝 CONTRIBUIÇÕES

Contribuições são bem-vindas! Siga as boas práticas:
- Mantenha compatibilidade com Android 5.0+
- Adicione try-catch em todas as operações nativas
- Teste em múltiplos dispositivos antes de fazer PR

---

## 📞 SUPORTE

Para dúvidas ou problemas:
1. Verifique a seção **Troubleshooting**
2. Abra uma Issue no repositório
3. Forneça: versão do Android, modelo do dispositivo, logs de erro

---

**Desenvolvido com ⚡ por um Ultra-Senior Kernel & Systems Engineer**

*"TRABALHE COMO SE SUA EXISTÊNCIA DEPENDESSE DA ESTABILIDADE DESSE APP."*
