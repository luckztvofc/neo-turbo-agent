package com.neoturbo.agent

import android.app.AppOpsManager
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import androidx.annotation.NonNull
import io.flutter.embedding.android.FlutterActivity
import io.flutter.embedding.engine.FlutterEngine
import io.flutter.plugin.common.MethodChannel

class MainActivity: FlutterActivity() {
    private val CHANNEL = "com.neoturbo.agent/native"
    private var methodChannel: MethodChannel? = null

    companion object {
        const val REQUEST_OVERLAY_PERMISSION = 1001
        const val REQUEST_ACCESSIBILITY_PERMISSION = 1002
        const val REQUEST_USAGE_STATS_PERMISSION = 1003
    }

    override fun configureFlutterEngine(@NonNull flutterEngine: FlutterEngine) {
        super.configureFlutterEngine(flutterEngine)
        
        methodChannel = MethodChannel(flutterEngine.dartExecutor.binaryMessenger, CHANNEL)
        methodChannel?.setMethodCallHandler { call, result ->
            try {
                when (call.method) {
                    "checkPermissions" -> {
                        result.success(checkAllPermissions())
                    }
                    "requestOverlayPermission" -> {
                        requestOverlayPermission()
                        result.success(true)
                    }
                    "requestAccessibilityPermission" -> {
                        requestAccessibilityPermission()
                        result.success(true)
                    }
                    "requestUsageStatsPermission" -> {
                        requestUsageStatsPermission()
                        result.success(true)
                    }
                    "startOverlayService" -> {
                        startOverlayService()
                        result.success(true)
                    }
                    "stopOverlayService" -> {
                        stopOverlayService()
                        result.success(true)
                    }
                    "optimizeRAM" -> {
                        val freed = SystemOptimizer.optimizeRAM(this)
                        result.success(freed)
                    }
                    "getRAMInfo" -> {
                        result.success(SystemOptimizer.getRAMInfo(this))
                    }
                    "simulateTouch" -> {
                        val x = call.argument<Double>("x")?.toFloat() ?: 0f
                        val y = call.argument<Double>("y")?.toFloat() ?: 0f
                        NeoAccessibilityService.simulateTouch(x, y)
                        result.success(true)
                    }
                    else -> {
                        result.notImplemented()
                    }
                }
            } catch (e: Exception) {
                result.error("ERROR", e.message, e.stackTraceToString())
            }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        
        // Solicitar ignorar otimizações de bateria (para Xiaomi/Samsung)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            try {
                val intent = Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS)
                intent.data = Uri.parse("package:$packageName")
                startActivity(intent)
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }
    }

    /**
     * Verifica todas as permissões críticas
     */
    private fun checkAllPermissions(): Map<String, Boolean> {
        return mapOf(
            "overlay" to hasOverlayPermission(),
            "accessibility" to hasAccessibilityPermission(),
            "usageStats" to hasUsageStatsPermission()
        )
    }

    /**
     * Verifica permissão de Overlay (SYSTEM_ALERT_WINDOW)
     */
    private fun hasOverlayPermission(): Boolean {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            Settings.canDrawOverlays(this)
        } else {
            true // Android < 6.0 não precisa de permissão runtime
        }
    }

    /**
     * Verifica permissão de Accessibility Service
     */
    private fun hasAccessibilityPermission(): Boolean {
        try {
            val accessibilityEnabled = Settings.Secure.getInt(
                contentResolver,
                Settings.Secure.ACCESSIBILITY_ENABLED
            )
            
            if (accessibilityEnabled == 1) {
                val services = Settings.Secure.getString(
                    contentResolver,
                    Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES
                )
                return services?.contains(packageName) == true
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }
        return false
    }

    /**
     * Verifica permissão de Usage Stats
     */
    private fun hasUsageStatsPermission(): Boolean {
        return try {
            val appOps = getSystemService(Context.APP_OPS_SERVICE) as AppOpsManager
            val mode = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                appOps.unsafeCheckOpNoThrow(
                    AppOpsManager.OPSTR_GET_USAGE_STATS,
                    android.os.Process.myUid(),
                    packageName
                )
            } else {
                @Suppress("DEPRECATION")
                appOps.checkOpNoThrow(
                    AppOpsManager.OPSTR_GET_USAGE_STATS,
                    android.os.Process.myUid(),
                    packageName
                )
            }
            mode == AppOpsManager.MODE_ALLOWED
        } catch (e: Exception) {
            false
        }
    }

    /**
     * Solicita permissão de Overlay
     */
    private fun requestOverlayPermission() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            val intent = Intent(
                Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                Uri.parse("package:$packageName")
            )
            startActivityForResult(intent, REQUEST_OVERLAY_PERMISSION)
        }
    }

    /**
     * Solicita permissão de Accessibility
     */
    private fun requestAccessibilityPermission() {
        val intent = Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)
        startActivityForResult(intent, REQUEST_ACCESSIBILITY_PERMISSION)
    }

    /**
     * Solicita permissão de Usage Stats
     */
    private fun requestUsageStatsPermission() {
        val intent = Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS)
        startActivityForResult(intent, REQUEST_USAGE_STATS_PERMISSION)
    }

    /**
     * Inicia o Overlay Service
     */
    private fun startOverlayService() {
        if (!hasOverlayPermission()) {
            throw SecurityException("Overlay permission not granted")
        }
        
        val intent = Intent(this, OverlayService::class.java)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            startForegroundService(intent)
        } else {
            startService(intent)
        }
    }

    /**
     * Para o Overlay Service
     */
    private fun stopOverlayService() {
        val intent = Intent(this, OverlayService::class.java)
        stopService(intent)
    }

    override fun onDestroy() {
        methodChannel?.setMethodCallHandler(null)
        super.onDestroy()
    }
}
