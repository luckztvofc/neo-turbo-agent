package com.neoturbo.agent

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.graphics.Path
import android.os.Build
import android.view.accessibility.AccessibilityEvent
import androidx.annotation.RequiresApi

class NeoAccessibilityService : AccessibilityService() {

    companion object {
        private var instance: NeoAccessibilityService? = null

        /**
         * Simula um toque na coordenada (x, y)
         * Chamado pelo Flutter via MethodChannel
         */
        fun simulateTouch(x: Float, y: Float) {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
                instance?.performTouchGesture(x, y)
            }
        }

        /**
         * Verifica se o serviço está ativo
         */
        fun isServiceEnabled(): Boolean {
            return instance != null
        }
    }

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        // Pode ser usado para monitorar eventos de apps
        // Por enquanto, não processamos eventos
    }

    override fun onInterrupt() {
        // Chamado quando o serviço é interrompido
    }

    /**
     * Executa um gesto de toque na tela
     * Requer Android 7.0+ (API 24)
     */
    @RequiresApi(Build.VERSION_CODES.N)
    private fun performTouchGesture(x: Float, y: Float) {
        try {
            val path = Path()
            path.moveTo(x, y)
            
            val gestureBuilder = GestureDescription.Builder()
            val strokeDescription = GestureDescription.StrokeDescription(
                path,
                0, // delay inicial
                50  // duração do toque (ms)
            )
            
            gestureBuilder.addStroke(strokeDescription)
            val gesture = gestureBuilder.build()
            
            dispatchGesture(gesture, object : GestureResultCallback() {
                override fun onCompleted(gestureDescription: GestureDescription?) {
                    super.onCompleted(gestureDescription)
                    // Toque executado com sucesso
                }

                override fun onCancelled(gestureDescription: GestureDescription?) {
                    super.onCancelled(gestureDescription)
                    // Toque cancelado
                }
            }, null)
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    /**
     * Executa um gesto de swipe (deslizar)
     */
    @RequiresApi(Build.VERSION_CODES.N)
    fun performSwipeGesture(startX: Float, startY: Float, endX: Float, endY: Float, duration: Long = 300) {
        try {
            val path = Path()
            path.moveTo(startX, startY)
            path.lineTo(endX, endY)
            
            val gestureBuilder = GestureDescription.Builder()
            val strokeDescription = GestureDescription.StrokeDescription(
                path,
                0,
                duration
            )
            
            gestureBuilder.addStroke(strokeDescription)
            val gesture = gestureBuilder.build()
            
            dispatchGesture(gesture, null, null)
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    /**
     * Executa múltiplos toques simultâneos (multi-touch)
     */
    @RequiresApi(Build.VERSION_CODES.N)
    fun performMultiTouch(coordinates: List<Pair<Float, Float>>) {
        try {
            val gestureBuilder = GestureDescription.Builder()
            
            coordinates.forEach { (x, y) ->
                val path = Path()
                path.moveTo(x, y)
                
                val strokeDescription = GestureDescription.StrokeDescription(
                    path,
                    0,
                    50
                )
                gestureBuilder.addStroke(strokeDescription)
            }
            
            val gesture = gestureBuilder.build()
            dispatchGesture(gesture, null, null)
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    override fun onDestroy() {
        instance = null
        super.onDestroy()
    }
}
