package com.neoturbo.agent

import android.app.ActivityManager
import android.content.Context
import android.os.Build
import java.io.RandomAccessFile

object SystemOptimizer {

    /**
     * Otimiza RAM matando processos em background
     * Retorna a quantidade aproximada de RAM liberada em MB
     */
    fun optimizeRAM(context: Context): Int {
        return try {
            val activityManager = context.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
            
            // Obter RAM antes da limpeza
            val memInfoBefore = getRAMInfo(context)
            val availableBefore = memInfoBefore["available"] as? Long ?: 0L
            
            // Obter lista de processos em execução
            val runningApps = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
                activityManager.runningAppProcesses
            } else {
                @Suppress("DEPRECATION")
                activityManager.runningAppProcesses
            }
            
            // Matar processos em background (exceto o próprio app)
            var killedCount = 0
            runningApps?.forEach { processInfo ->
                if (processInfo.importance >= ActivityManager.RunningAppProcessInfo.IMPORTANCE_BACKGROUND) {
                    if (processInfo.processName != context.packageName) {
                        try {
                            activityManager.killBackgroundProcesses(processInfo.processName)
                            killedCount++
                        } catch (e: Exception) {
                            // Ignorar erros de permissão
                        }
                    }
                }
            }
            
            // Forçar garbage collection
            System.gc()
            
            // Aguardar um pouco para o sistema atualizar
            Thread.sleep(500)
            
            // Obter RAM depois da limpeza
            val memInfoAfter = getRAMInfo(context)
            val availableAfter = memInfoAfter["available"] as? Long ?: 0L
            
            // Calcular RAM liberada em MB
            val freedMB = ((availableAfter - availableBefore) / (1024 * 1024)).toInt()
            
            freedMB.coerceAtLeast(0)
        } catch (e: Exception) {
            e.printStackTrace()
            0
        }
    }

    /**
     * Obtém informações sobre RAM do sistema
     * Retorna um Map com: total, available, used, usedPercentage
     */
    fun getRAMInfo(context: Context): Map<String, Any> {
        return try {
            val activityManager = context.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
            val memInfo = ActivityManager.MemoryInfo()
            activityManager.getMemoryInfo(memInfo)
            
            val totalRAM = getTotalRAM()
            val availableRAM = memInfo.availMem
            val usedRAM = totalRAM - availableRAM
            val usedPercentage = if (totalRAM > 0) {
                ((usedRAM.toDouble() / totalRAM.toDouble()) * 100).toInt()
            } else {
                0
            }
            
            mapOf(
                "total" to totalRAM,
                "available" to availableRAM,
                "used" to usedRAM,
                "usedPercentage" to usedPercentage,
                "totalMB" to (totalRAM / (1024 * 1024)),
                "availableMB" to (availableRAM / (1024 * 1024)),
                "usedMB" to (usedRAM / (1024 * 1024)),
                "isLowMemory" to memInfo.lowMemory,
                "threshold" to memInfo.threshold
            )
        } catch (e: Exception) {
            e.printStackTrace()
            mapOf(
                "total" to 0L,
                "available" to 0L,
                "used" to 0L,
                "usedPercentage" to 0,
                "totalMB" to 0L,
                "availableMB" to 0L,
                "usedMB" to 0L,
                "isLowMemory" to false,
                "threshold" to 0L
            )
        }
    }

    /**
     * Obtém a RAM total do dispositivo
     * Lê diretamente do /proc/meminfo para maior precisão
     */
    private fun getTotalRAM(): Long {
        return try {
            val reader = RandomAccessFile("/proc/meminfo", "r")
            val line = reader.readLine()
            reader.close()
            
            // Formato: "MemTotal:        3951236 kB"
            val parts = line.split("\\s+".toRegex())
            if (parts.size >= 2) {
                val totalKB = parts[1].toLongOrNull() ?: 0L
                totalKB * 1024 // Converter para bytes
            } else {
                0L
            }
        } catch (e: Exception) {
            e.printStackTrace()
            // Fallback: usar ActivityManager (menos preciso)
            try {
                val activityManager = android.app.ActivityManager()
                val memInfo = ActivityManager.MemoryInfo()
                activityManager.getMemoryInfo(memInfo)
                memInfo.totalMem
            } catch (e2: Exception) {
                0L
            }
        }
    }

    /**
     * Obtém informações de CPU (uso percentual)
     * Nota: Requer múltiplas leituras para calcular uso
     */
    fun getCPUUsage(): Int {
        return try {
            val reader = RandomAccessFile("/proc/stat", "r")
            val line = reader.readLine()
            reader.close()
            
            // Formato: "cpu  user nice system idle iowait irq softirq"
            val parts = line.split("\\s+".toRegex())
            if (parts.size >= 5) {
                val user = parts[1].toLongOrNull() ?: 0L
                val nice = parts[2].toLongOrNull() ?: 0L
                val system = parts[3].toLongOrNull() ?: 0L
                val idle = parts[4].toLongOrNull() ?: 0L
                
                val total = user + nice + system + idle
                val used = user + nice + system
                
                if (total > 0) {
                    ((used.toDouble() / total.toDouble()) * 100).toInt()
                } else {
                    0
                }
            } else {
                0
            }
        } catch (e: Exception) {
            e.printStackTrace()
            0
        }
    }

    /**
     * Limpa cache de apps (requer permissão de sistema - pode não funcionar)
     */
    fun clearAppCache(context: Context) {
        try {
            val activityManager = context.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
            // Esta função requer permissão de sistema
            // activityManager.clearApplicationUserData() // Não disponível para apps normais
            
            // Alternativa: limpar cache do próprio app
            context.cacheDir.deleteRecursively()
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }
}
