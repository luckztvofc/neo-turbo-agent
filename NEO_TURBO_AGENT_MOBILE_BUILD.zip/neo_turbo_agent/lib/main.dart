import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:provider/provider.dart';
import 'package:flutter_spinkit/flutter_spinkit.dart';
import 'package:animated_text_kit/animated_text_kit.dart';
import 'dart:async';

void main() {
  WidgetsFlutterBinding.ensureInitialized();
  
  // Forçar orientação portrait
  SystemChrome.setPreferredOrientations([
    DeviceOrientation.portraitUp,
    DeviceOrientation.portraitDown,
  ]);
  
  // Configurar UI do sistema
  SystemChrome.setSystemUIOverlayStyle(
    const SystemUiOverlayStyle(
      statusBarColor: Colors.transparent,
      statusBarIconBrightness: Brightness.light,
      systemNavigationBarColor: Color(0xFF0a0e27),
      systemNavigationBarIconBrightness: Brightness.light,
    ),
  );
  
  runApp(
    ChangeNotifierProvider(
      create: (_) => NeoTurboState(),
      child: const NeoTurboApp(),
    ),
  );
}

class NeoTurboApp extends StatelessWidget {
  const NeoTurboApp({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'NEO TURBO AGENT',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        brightness: Brightness.dark,
        primaryColor: const Color(0xFF00f3ff), // Cyan
        scaffoldBackgroundColor: const Color(0xFF0a0e27),
        colorScheme: const ColorScheme.dark(
          primary: Color(0xFF00f3ff),
          secondary: Color(0xFF39ff14), // Neon Green
          background: Color(0xFF0a0e27),
          surface: Color(0xFF1a1f3a),
        ),
        textTheme: const TextTheme(
          displayLarge: TextStyle(
            color: Color(0xFF00f3ff),
            fontWeight: FontWeight.bold,
            fontSize: 32,
          ),
          bodyLarge: TextStyle(
            color: Colors.white,
            fontSize: 16,
          ),
        ),
      ),
      home: const NeoTurboHome(),
    );
  }
}

class NeoTurboHome extends StatefulWidget {
  const NeoTurboHome({Key? key}) : super(key: key);

  @override
  State<NeoTurboHome> createState() => _NeoTurboHomeState();
}

class _NeoTurboHomeState extends State<NeoTurboHome> {
  Timer? _ramUpdateTimer;

  @override
  void initState() {
    super.initState();
    _initializeApp();
  }

  Future<void> _initializeApp() async {
    final state = context.read<NeoTurboState>();
    await state.checkPermissions();
    await state.updateRAMInfo();
    
    // Atualizar RAM a cada 2 segundos
    _ramUpdateTimer = Timer.periodic(const Duration(seconds: 2), (_) {
      state.updateRAMInfo();
    });
  }

  @override
  void dispose() {
    _ramUpdateTimer?.cancel();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        decoration: const BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
            colors: [
              Color(0xFF0a0e27),
              Color(0xFF1a1f3a),
              Color(0xFF0a0e27),
            ],
          ),
        ),
        child: SafeArea(
          child: Column(
            children: [
              _buildHeader(),
              Expanded(
                child: SingleChildScrollView(
                  padding: const EdgeInsets.all(20),
                  child: Column(
                    children: [
                      _buildRAMMonitor(),
                      const SizedBox(height: 20),
                      _buildPermissionsStatus(),
                      const SizedBox(height: 20),
                      _buildTurboButton(),
                      const SizedBox(height: 20),
                      _buildControlButtons(),
                    ],
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildHeader() {
    return Container(
      padding: const EdgeInsets.all(20),
      child: Column(
        children: [
          AnimatedTextKit(
            animatedTexts: [
              TypewriterAnimatedText(
                'NEO TURBO AGENT',
                textStyle: const TextStyle(
                  fontSize: 28,
                  fontWeight: FontWeight.bold,
                  color: Color(0xFF00f3ff),
                  letterSpacing: 2,
                ),
                speed: const Duration(milliseconds: 100),
              ),
            ],
            totalRepeatCount: 1,
          ),
          const SizedBox(height: 5),
          const Text(
            'GAME OPTIMIZER',
            style: TextStyle(
              fontSize: 12,
              color: Color(0xFF39ff14),
              letterSpacing: 4,
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildRAMMonitor() {
    return Consumer<NeoTurboState>(
      builder: (context, state, _) {
        return Container(
          padding: const EdgeInsets.all(20),
          decoration: BoxDecoration(
            color: const Color(0xFF1a1f3a).withOpacity(0.5),
            borderRadius: BorderRadius.circular(15),
            border: Border.all(
              color: const Color(0xFF00f3ff).withOpacity(0.3),
              width: 2,
            ),
            boxShadow: [
              BoxShadow(
                color: const Color(0xFF00f3ff).withOpacity(0.2),
                blurRadius: 20,
                spreadRadius: 2,
              ),
            ],
          ),
          child: Column(
            children: [
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  const Text(
                    'RAM STATUS',
                    style: TextStyle(
                      color: Color(0xFF00f3ff),
                      fontSize: 16,
                      fontWeight: FontWeight.bold,
                      letterSpacing: 2,
                    ),
                  ),
                  if (state.isLoadingRAM)
                    const SpinKitPulse(
                      color: Color(0xFF39ff14),
                      size: 20,
                    ),
                ],
              ),
              const SizedBox(height: 20),
              _buildRAMBar(state.ramUsedPercentage),
              const SizedBox(height: 15),
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  _buildRAMStat('TOTAL', '${state.ramTotalMB} MB'),
                  _buildRAMStat('USED', '${state.ramUsedMB} MB'),
                  _buildRAMStat('FREE', '${state.ramAvailableMB} MB'),
                ],
              ),
            ],
          ),
        );
      },
    );
  }

  Widget _buildRAMBar(int percentage) {
    return Column(
      children: [
        Stack(
          children: [
            Container(
              height: 30,
              decoration: BoxDecoration(
                color: Colors.black.withOpacity(0.5),
                borderRadius: BorderRadius.circular(15),
              ),
            ),
            Container(
              height: 30,
              width: MediaQuery.of(context).size.width * (percentage / 100),
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  colors: [
                    const Color(0xFF00f3ff),
                    percentage > 80 ? Colors.red : const Color(0xFF39ff14),
                  ],
                ),
                borderRadius: BorderRadius.circular(15),
                boxShadow: [
                  BoxShadow(
                    color: const Color(0xFF00f3ff).withOpacity(0.5),
                    blurRadius: 10,
                  ),
                ],
              ),
            ),
            Container(
              height: 30,
              alignment: Alignment.center,
              child: Text(
                '$percentage%',
                style: const TextStyle(
                  color: Colors.white,
                  fontWeight: FontWeight.bold,
                  fontSize: 16,
                ),
              ),
            ),
          ],
        ),
      ],
    );
  }

  Widget _buildRAMStat(String label, String value) {
    return Column(
      children: [
        Text(
          label,
          style: const TextStyle(
            color: Color(0xFF39ff14),
            fontSize: 10,
            letterSpacing: 1,
          ),
        ),
        const SizedBox(height: 5),
        Text(
          value,
          style: const TextStyle(
            color: Colors.white,
            fontSize: 14,
            fontWeight: FontWeight.bold,
          ),
        ),
      ],
    );
  }

  Widget _buildPermissionsStatus() {
    return Consumer<NeoTurboState>(
      builder: (context, state, _) {
        return Container(
          padding: const EdgeInsets.all(20),
          decoration: BoxDecoration(
            color: const Color(0xFF1a1f3a).withOpacity(0.5),
            borderRadius: BorderRadius.circular(15),
            border: Border.all(
              color: const Color(0xFF39ff14).withOpacity(0.3),
              width: 2,
            ),
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const Text(
                'PERMISSIONS',
                style: TextStyle(
                  color: Color(0xFF39ff14),
                  fontSize: 16,
                  fontWeight: FontWeight.bold,
                  letterSpacing: 2,
                ),
              ),
              const SizedBox(height: 15),
              _buildPermissionItem(
                'Overlay Window',
                state.hasOverlayPermission,
                () => state.requestOverlayPermission(),
              ),
              _buildPermissionItem(
                'Accessibility Service',
                state.hasAccessibilityPermission,
                () => state.requestAccessibilityPermission(),
              ),
              _buildPermissionItem(
                'Usage Stats',
                state.hasUsageStatsPermission,
                () => state.requestUsageStatsPermission(),
              ),
            ],
          ),
        );
      },
    );
  }

  Widget _buildPermissionItem(String name, bool granted, VoidCallback onRequest) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 8),
      child: Row(
        children: [
          Icon(
            granted ? Icons.check_circle : Icons.lock,
            color: granted ? const Color(0xFF39ff14) : Colors.red,
            size: 24,
          ),
          const SizedBox(width: 10),
          Expanded(
            child: Text(
              name,
              style: const TextStyle(
                color: Colors.white,
                fontSize: 14,
              ),
            ),
          ),
          if (!granted)
            TextButton(
              onPressed: onRequest,
              child: const Text(
                'GRANT',
                style: TextStyle(
                  color: Color(0xFF00f3ff),
                  fontWeight: FontWeight.bold,
                ),
              ),
            ),
        ],
      ),
    );
  }

  Widget _buildTurboButton() {
    return Consumer<NeoTurboState>(
      builder: (context, state, _) {
        final isEnabled = state.allPermissionsGranted;
        final isActive = state.isTurboActive;
        
        return GestureDetector(
          onTap: isEnabled ? () => state.toggleTurbo() : null,
          child: Container(
            width: 200,
            height: 200,
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              gradient: isEnabled
                  ? RadialGradient(
                      colors: isActive
                          ? [
                              const Color(0xFF39ff14),
                              const Color(0xFF00f3ff),
                            ]
                          : [
                              const Color(0xFF00f3ff),
                              const Color(0xFF1a1f3a),
                            ],
                    )
                  : const RadialGradient(
                      colors: [
                        Colors.grey,
                        Color(0xFF1a1f3a),
                      ],
                    ),
              boxShadow: isEnabled
                  ? [
                      BoxShadow(
                        color: isActive
                            ? const Color(0xFF39ff14).withOpacity(0.5)
                            : const Color(0xFF00f3ff).withOpacity(0.5),
                        blurRadius: 30,
                        spreadRadius: 10,
                      ),
                    ]
                  : [],
            ),
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Icon(
                  isEnabled ? (isActive ? Icons.flash_on : Icons.flash_off) : Icons.lock,
                  size: 80,
                  color: Colors.white,
                ),
                const SizedBox(height: 10),
                Text(
                  isEnabled ? (isActive ? 'ACTIVE' : 'TURBO') : 'LOCKED',
                  style: const TextStyle(
                    color: Colors.white,
                    fontSize: 20,
                    fontWeight: FontWeight.bold,
                    letterSpacing: 2,
                  ),
                ),
              ],
            ),
          ),
        );
      },
    );
  }

  Widget _buildControlButtons() {
    return Consumer<NeoTurboState>(
      builder: (context, state, _) {
        return Column(
          children: [
            _buildActionButton(
              'OPTIMIZE RAM',
              Icons.memory,
              () async {
                final freed = await state.optimizeRAM();
                if (mounted) {
                  ScaffoldMessenger.of(context).showSnackBar(
                    SnackBar(
                      content: Text('RAM liberada: $freed MB'),
                      backgroundColor: const Color(0xFF39ff14),
                    ),
                  );
                }
              },
              state.isOptimizing,
            ),
            const SizedBox(height: 10),
            _buildActionButton(
              'REFRESH STATUS',
              Icons.refresh,
              () {
                state.checkPermissions();
                state.updateRAMInfo();
              },
              false,
            ),
          ],
        );
      },
    );
  }

  Widget _buildActionButton(
    String label,
    IconData icon,
    VoidCallback onPressed,
    bool isLoading,
  ) {
    return ElevatedButton(
      onPressed: isLoading ? null : onPressed,
      style: ElevatedButton.styleFrom(
        backgroundColor: const Color(0xFF1a1f3a),
        foregroundColor: const Color(0xFF00f3ff),
        padding: const EdgeInsets.symmetric(horizontal: 30, vertical: 15),
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(10),
          side: const BorderSide(
            color: Color(0xFF00f3ff),
            width: 2,
          ),
        ),
      ),
      child: isLoading
          ? const SpinKitThreeBounce(
              color: Color(0xFF00f3ff),
              size: 20,
            )
          : Row(
              mainAxisSize: MainAxisSize.min,
              children: [
                Icon(icon),
                const SizedBox(width: 10),
                Text(
                  label,
                  style: const TextStyle(
                    fontSize: 16,
                    fontWeight: FontWeight.bold,
                    letterSpacing: 1,
                  ),
                ),
              ],
            ),
    );
  }
}

// ========== STATE MANAGEMENT ==========

class NeoTurboState extends ChangeNotifier {
  static const platform = MethodChannel('com.neoturbo.agent/native');

  // Permissions
  bool hasOverlayPermission = false;
  bool hasAccessibilityPermission = false;
  bool hasUsageStatsPermission = false;

  // RAM Info
  int ramTotalMB = 0;
  int ramAvailableMB = 0;
  int ramUsedMB = 0;
  int ramUsedPercentage = 0;
  bool isLoadingRAM = false;

  // Turbo State
  bool isTurboActive = false;
  bool isOptimizing = false;

  bool get allPermissionsGranted =>
      hasOverlayPermission && hasAccessibilityPermission && hasUsageStatsPermission;

  /// Verifica todas as permissões
  Future<void> checkPermissions() async {
    try {
      final result = await platform.invokeMethod('checkPermissions');
      if (result is Map) {
        hasOverlayPermission = result['overlay'] ?? false;
        hasAccessibilityPermission = result['accessibility'] ?? false;
        hasUsageStatsPermission = result['usageStats'] ?? false;
        notifyListeners();
      }
    } catch (e) {
      print('Error checking permissions: $e');
    }
  }

  /// Solicita permissão de Overlay
  Future<void> requestOverlayPermission() async {
    try {
      await platform.invokeMethod('requestOverlayPermission');
      await Future.delayed(const Duration(seconds: 1));
      await checkPermissions();
    } catch (e) {
      print('Error requesting overlay permission: $e');
    }
  }

  /// Solicita permissão de Accessibility
  Future<void> requestAccessibilityPermission() async {
    try {
      await platform.invokeMethod('requestAccessibilityPermission');
      await Future.delayed(const Duration(seconds: 1));
      await checkPermissions();
    } catch (e) {
      print('Error requesting accessibility permission: $e');
    }
  }

  /// Solicita permissão de Usage Stats
  Future<void> requestUsageStatsPermission() async {
    try {
      await platform.invokeMethod('requestUsageStatsPermission');
      await Future.delayed(const Duration(seconds: 1));
      await checkPermissions();
    } catch (e) {
      print('Error requesting usage stats permission: $e');
    }
  }

  /// Atualiza informações de RAM
  Future<void> updateRAMInfo() async {
    if (isLoadingRAM) return;
    
    isLoadingRAM = true;
    notifyListeners();

    try {
      final result = await platform.invokeMethod('getRAMInfo');
      if (result is Map) {
        ramTotalMB = result['totalMB'] ?? 0;
        ramAvailableMB = result['availableMB'] ?? 0;
        ramUsedMB = result['usedMB'] ?? 0;
        ramUsedPercentage = result['usedPercentage'] ?? 0;
      }
    } catch (e) {
      print('Error getting RAM info: $e');
    } finally {
      isLoadingRAM = false;
      notifyListeners();
    }
  }

  /// Otimiza RAM
  Future<int> optimizeRAM() async {
    if (isOptimizing) return 0;
    
    isOptimizing = true;
    notifyListeners();

    try {
      final freed = await platform.invokeMethod('optimizeRAM');
      await updateRAMInfo();
      return freed ?? 0;
    } catch (e) {
      print('Error optimizing RAM: $e');
      return 0;
    } finally {
      isOptimizing = false;
      notifyListeners();
    }
  }

  /// Ativa/Desativa Turbo Mode
  Future<void> toggleTurbo() async {
    if (!allPermissionsGranted) return;

    try {
      if (isTurboActive) {
        await platform.invokeMethod('stopOverlayService');
        isTurboActive = false;
      } else {
        await platform.invokeMethod('startOverlayService');
        isTurboActive = true;
      }
      notifyListeners();
    } catch (e) {
      print('Error toggling turbo: $e');
    }
  }

  /// Simula toque em coordenadas
  Future<void> simulateTouch(double x, double y) async {
    try {
      await platform.invokeMethod('simulateTouch', {'x': x, 'y': y});
    } catch (e) {
      print('Error simulating touch: $e');
    }
  }
}
